package com.example.sensor_scan

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
