package com.sensorscan.aether.sensor_scan

import io.flutter.embedding.android.FlutterActivity
import android.os.Bundle
import android.telephony.SmsManager
import android.widget.Toast
import io.flutter.plugin.common.MethodChannel
import android.Manifest
import android.content.pm.PackageManager
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import android.content.Context

class MainActivity: FlutterActivity() {
    private val SMS_CHANNEL = "com.sensorscan.aether.sensor_scan/sms"
    private val NATIVE_CHANNEL = "com.sensorscan.aether.sensor_scan/native"
    private val SMS_PERMISSION_CODE = 1

    override fun configureFlutterEngine(flutterEngine: io.flutter.embedding.engine.FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, SMS_CHANNEL).setMethodCallHandler { call, result ->
            if (call.method == "sendSMS") {
                val phoneNumber = call.argument<String>("phoneNumber")
                val message = call.argument<String>("message")
                if (phoneNumber != null && message != null) {
                    sendSMS(phoneNumber, message, result)
                } else {
                    result.error("INVALID_ARGUMENTS", "Phone number or message is null", null)
                }
            } else {
                result.notImplemented()
            }
        }

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, NATIVE_CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {
                "saveEmergencyContact" -> {
                    val contacts = call.argument<List<String>>("contacts")
                    if (contacts != null) {
                        saveEmergencyContacts(contacts)
                        result.success(null)
                    } else {
                        result.error("INVALID_ARGUMENTS", "Contacts list is null", null)
                    }
                }
                "saveEmergencyMessage" -> {
                    val message = call.argument<String>("message")
                    if (message != null) {
                        saveEmergencyMessage(message)
                        result.success(null)
                    } else {
                        result.error("INVALID_ARGUMENTS", "message list is null", null)
                    }
                }
                "loadEmergencyMessage" -> {
                    val message = loadEmergencyMessage()
                    result.success(message)
                }
                "loadEmergencyContact" -> {
                    val contacts = loadEmergencyContacts()
                    result.success(contacts)
                }
                else -> {
                    result.notImplemented()
                }
            }
        }
    }

    private fun sendSMS(phoneNumber: String, message: String, result: MethodChannel.Result) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            // Request SMS permission if not granted
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.SEND_SMS), SMS_PERMISSION_CODE)
            result.error("PERMISSION_DENIED", "SMS permission denied", null)
            return
        }
        try {
            val smsManager = SmsManager.getDefault()
            val parts = smsManager.divideMessage(message)
            smsManager.sendMultipartTextMessage(phoneNumber, null, parts, null, null)
            result.success("SMS Sent")
        } catch (e: Exception) {
            result.error("SMS_FAILED", "Failed to send SMS: ${e.message}", null)
        }
    }

    private fun saveEmergencyContacts(contacts: List<String>) {
        val sharedPref = getSharedPreferences("EmergencyContacts", Context.MODE_PRIVATE)
        with(sharedPref.edit()) {
            putStringSet("contacts", contacts.toSet())
            apply()
        }
    }

    private fun loadEmergencyContacts(): List<String> {
        val sharedPref = getSharedPreferences("EmergencyContacts", Context.MODE_PRIVATE)
        return sharedPref.getStringSet("contacts", emptySet())?.toList() ?: emptyList()
    }

    private fun saveEmergencyMessage(message: String) {
        val sharedPref = getSharedPreferences("EmergencyMessage", Context.MODE_PRIVATE)
        with(sharedPref.edit()) {
            putString("message", message)
            apply()
        }
    }

    private fun loadEmergencyMessage(): String? {
        val sharedPref = getSharedPreferences("EmergencyMessage", Context.MODE_PRIVATE)
        return sharedPref.getString("message", null)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == SMS_PERMISSION_CODE) {
            if ((grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                Toast.makeText(this, "SMS Permission Granted", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "SMS Permission Denied", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
