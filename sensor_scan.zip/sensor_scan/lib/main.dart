import 'package:flutter/material.dart';
import 'package:sensors_plus/sensors_plus.dart';
import 'package:geolocator/geolocator.dart';
import 'dart:async';
import 'dart:math';
import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:map_launcher/map_launcher.dart';

void main() {
  runApp(const EmergencyHelperApp());
}

class EmergencyHelperApp extends StatelessWidget {
  const EmergencyHelperApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Emergency Helper',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.teal),
        useMaterial3: true,
      ),
      home: const HomeScreen(title: 'Emergency Helper Home'),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.title});

  final String title;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  static const smsChannel =
  MethodChannel('com.sensorscan.aether.sensor_scan/sms');
  static const nativeChannel =
  MethodChannel('com.sensorscan.aether.sensor_scan/native');

  String statusMessage = "All systems normal.";
  double? currentAcceleration;
  AccelerometerEvent? accelEvent;
  GyroscopeEvent? gyroEvent;
  // Variables for filtered linear acceleration (motion only)
  double? filteredAccelerationX;
  double? filteredAccelerationY;
  double? filteredAccelerationZ;
  double? filteredAccelerationMagnitude;
  MagnetometerEvent? magnetEvent;
  double currentPitch = 0.0;
  double currentRoll = 0.0;
  double currentYaw = 0.0;
  bool alertSent = false; // To track if an alert has been sent in the current session
  double gravityX = 0.0;
  double gravityY = 0.0;
  double gravityZ = 0.0;
  double alpha = 0.8; // Filter coefficient
  Position? userPosition;
  Timer? positionTimer;

  final List<StreamSubscription<dynamic>> subscriptions = [];
  bool isAccelAvailable = true;
  bool isGyroAvailable = true;
  bool isMagnetAvailable = true;

  DateTime? lastGyroUpdate;
  final double gyroSmoothing = 0.95;

  List<String> contacts = [];
  String userCustomMessage = '';

  @override
  void initState() {
    super.initState();
    setupSensors();
    requestAppPermissions();

    // Load contacts and custom message concurrently
    loadContacts();
    loadCustomMessage();

    positionTimer = Timer.periodic(const Duration(minutes: 2), (Timer t) {
      fetchCurrentLocation();
    });
  }

  @override
  void dispose() {
    for (var subscription in subscriptions) {
      subscription.cancel();
    }
    positionTimer?.cancel();
    super.dispose();
  }

  Future<void> requestAppPermissions() async {
    // Request SMS Permission
    PermissionStatus smsStatus = await Permission.sms.status;
    if (!smsStatus.isGranted) {
      smsStatus = await Permission.sms.request();
      if (!smsStatus.isGranted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('SMS permission is essential to send alerts.'),
          ),
        );
      }
    }

    // Request Location Permission
    PermissionStatus locationStatus = await Permission.location.status;
    if (!locationStatus.isGranted) {
      locationStatus = await Permission.location.request();
      if (!locationStatus.isGranted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Location permission is essential for this app.'),
          ),
        );
      } else {
        fetchCurrentLocation();
      }
    } else {
      fetchCurrentLocation();
    }
  }

  Future<void> saveContactsList(List<String> contactList) async {
    try {
      await nativeChannel
          .invokeMethod('saveEmergencyContact', {'contacts': contactList});
    } on PlatformException catch (e) {
      print("Error saving contacts: ${e.message}");
    }
  }

  Future<void> loadContacts() async {
    try {
      final List<dynamic>? fetchedContacts =
      await nativeChannel.invokeMethod('loadEmergencyContact');
      setState(() {
        contacts = fetchedContacts?.cast<String>() ?? [];
      });
    } on PlatformException catch (e) {
      print("Error loading contacts: ${e.message}");
      setState(() {
        contacts = [];
      });
    }
  }

  Future<void> saveCustomMessage(String message) async {
    try {
      await nativeChannel.invokeMethod('saveEmergencyMessage', {'message': message});
      setState(() {
        userCustomMessage = message;
      });
    } on PlatformException catch (e) {
      print("Error saving custom message: ${e.message}");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to save message: ${e.message}'),
        ),
      );
    }
  }

  Future<void> loadCustomMessage() async {
    try {
      final String? loadedMessage =
      await nativeChannel.invokeMethod('loadEmergencyMessage');
      setState(() {
        userCustomMessage = loadedMessage ?? '';
      });
    } on PlatformException catch (e) {
      print("Error loading custom message: ${e.message}");
      setState(() {
        userCustomMessage = '';
      });
    }
  }

  void setupSensors() {
    initializeAccelerometer();
    initializeGyroscope();
    initializeMagnetometer();
  }

  // void initializeAccelerometer() {
  //   var accelSubscription = accelerometerEvents.listen(
  //         (AccelerometerEvent event) {
  //       setState(() {
  //         accelEvent = event;
  //         currentAcceleration = sqrt(
  //           event.x * event.x + event.y * event.y + event.z * event.z,
  //         );
  //       });
  //
  //       detectFall(currentAcceleration);
  //     },
  //     onError: (error) {
  //       print('Accelerometer error: $error');
  //       isAccelAvailable = false;
  //       setState(() {});
  //       displaySensorError("Accelerometer");
  //     },
  //     cancelOnError: true,
  //   );
  //
  //   subscriptions.add(accelSubscription);
  // }

  // void initializeAccelerometer() {
  //   var accelSubscription = accelerometerEvents.listen(
  //         (AccelerometerEvent event) {
  //       setState(() {
  //         // Raw accelerometer data for compass and level functionality
  //         accelEvent = event;
  //         currentAcceleration = sqrt(
  //           event.x * event.x + event.y * event.y + event.z * event.z,
  //         );
  //
  //         // Gravity filtering for fall detection
  //         gravityX = alpha * gravityX + (1 - alpha) * event.x;
  //         gravityY = alpha * gravityY + (1 - alpha) * event.y;
  //         gravityZ = alpha * gravityZ + (1 - alpha) * event.z;
  //
  //         // Remove gravity for motion-only acceleration
  //         double linearX = event.x - gravityX;
  //         double linearY = event.y - gravityY;
  //         double linearZ = event.z - gravityZ;
  //
  //         // Compute the magnitude of motion-only acceleration
  //         double filteredAcceleration = sqrt(
  //           linearX * linearX + linearY * linearY + linearZ * linearZ,
  //         );
  //
  //         // Pass filtered acceleration for fall detection
  //         detectFall(filteredAcceleration);
  //       });
  //
  //       // Use raw accelerometer data for orientation calculations
  //       if (magnetEvent != null) {
  //         computeOrientationFromAccelMag(event, magnetEvent!);
  //       }
  //     },
  //     onError: (error) {
  //       print('Accelerometer error: $error');
  //       isAccelAvailable = false;
  //       setState(() {});
  //       displaySensorError("Accelerometer");
  //     },
  //     cancelOnError: true,
  //   );
  //
  //   subscriptions.add(accelSubscription);
  // }
  void initializeAccelerometer() {
    var accelSubscription = accelerometerEvents.listen(
          (AccelerometerEvent event) {
        setState(() {
          // Raw accelerometer data for compass and level functionality
          accelEvent = event;
          currentAcceleration = sqrt(
            event.x * event.x + event.y * event.y + event.z * event.z,
          );

          // Gravity filtering for fall detection and UI
          gravityX = alpha * gravityX + (1 - alpha) * event.x;
          gravityY = alpha * gravityY + (1 - alpha) * event.y;
          gravityZ = alpha * gravityZ + (1 - alpha) * event.z;

          // Remove gravity to get the linear acceleration
          double linearX = event.x - gravityX;
          double linearY = event.y - gravityY;
          double linearZ = event.z - gravityZ;

          // Store filtered acceleration components for UI
          filteredAccelerationX = linearX;
          filteredAccelerationY = linearY;
          filteredAccelerationZ = linearZ;
          filteredAccelerationMagnitude = sqrt(
            linearX * linearX + linearY * linearY + linearZ * linearZ,
          );

          // Pass filtered acceleration for fall detection
          detectFall(filteredAccelerationMagnitude);
        });

        // Use raw accelerometer data for orientation calculations
        if (magnetEvent != null) {
          computeOrientationFromAccelMag(event, magnetEvent!);
        }
      },
      onError: (error) {
        print('Accelerometer error: $error');
        isAccelAvailable = false;
        setState(() {});
        displaySensorError("Accelerometer");
      },
      cancelOnError: true,
    );

    subscriptions.add(accelSubscription);
  }
  // void initializeAccelerometer() {
  //   double gravityX = 0.0;
  //   double gravityY = 0.0;
  //   double gravityZ = 0.0;
  //   double alpha = 0.8; // Filter coefficient
  //   var accelSubscription = accelerometerEvents.listen(
  //         (AccelerometerEvent event) {
  //       setState(() {
  //         // Isolate gravity using a low-pass filter
  //         gravityX = alpha * gravityX + (1 - alpha) * event.x;
  //         gravityY = alpha * gravityY + (1 - alpha) * event.y;
  //         gravityZ = alpha * gravityZ + (1 - alpha) * event.z;
  //
  //         // Remove gravity from the accelerometer data
  //         double linearX = event.x - gravityX;
  //         double linearY = event.y - gravityY;
  //         double linearZ = event.z - gravityZ;
  //
  //         // Calculate the magnitude of linear acceleration (motion-only)
  //         currentAcceleration = sqrt(
  //           linearX * linearX + linearY * linearY + linearZ * linearZ,
  //         );
  //       });
  //
  //       // Detect fall with filtered acceleration
  //       detectFall(currentAcceleration);
  //     },
  //     onError: (error) {
  //       print('Accelerometer error: $error');
  //       isAccelAvailable = false;
  //       setState(() {});
  //       displaySensorError("Accelerometer");
  //     },
  //     cancelOnError: true,
  //   );
  //
  //   subscriptions.add(accelSubscription);
  // }

  // void detectFall(double? acceleration) {
  //   if (acceleration != null && acceleration > 10.0) { // Threshold for fall detection
  //     print("Fall detected! Acceleration: $acceleration m/s²");
  //     dispatchEmergencyAlert();
  //   }
  // }

  void detectFall(double? acceleration) {
    // Define thresholds
    const double accelerationThreshold = 10.0; // m/s²
    const double orientationThreshold = 45.0; // degrees

    if (!alertSent && acceleration != null && acceleration > accelerationThreshold) {
      // Check if the orientation is skewed
      if (currentPitch.abs() > orientationThreshold ||
          currentRoll.abs() > orientationThreshold) {
        print("Fall detected! Acceleration: $acceleration m/s², "
            "Pitch: ${currentPitch.toStringAsFixed(1)}°, "
            "Roll: ${currentRoll.toStringAsFixed(1)}°");

        // Dispatch emergency alert and set flag
        dispatchEmergencyAlert();
        alertSent = true; // Ensure the alert is only sent once
      } else {
        print("High acceleration detected but orientation is normal.");
      }
    }
  }

  void initializeGyroscope() {
    var gyroSubscription = gyroscopeEvents.listen(
          (GyroscopeEvent event) {
        setState(() {
          gyroEvent = event;
          computeOrientationFromGyro(event);
        });
      },
      onError: (error) {
        print('Gyroscope error: $error');
        isGyroAvailable = false;
        setState(() {});
        displaySensorError("Gyroscope");
      },
      cancelOnError: true,
    );

    subscriptions.add(gyroSubscription);
  }

  void initializeMagnetometer() {
    var magnetSubscription = magnetometerEvents.listen(
          (MagnetometerEvent event) {
        setState(() {
          magnetEvent = event;
          if (accelEvent != null) {
            computeOrientationFromAccelMag(accelEvent!, event);
          }
        });
      },
      onError: (error) {
        print('Magnetometer error: $error');
        isMagnetAvailable = false;
        setState(() {});
        displaySensorError("Magnetometer");
      },
      cancelOnError: true,
    );

    subscriptions.add(magnetSubscription);
  }

  void displaySensorError(String sensorName) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text("$sensorName Unavailable"),
          content: Text(
              "Your device does not support the $sensorName sensor required for this app."),
          actions: <Widget>[
            TextButton(
              child: const Text("Understood"),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  void computeOrientationFromAccelMag(
      AccelerometerEvent accel, MagnetometerEvent magnet) {
    currentPitch = (atan2(accel.y, accel.z) * 180 / pi).toDouble();
    currentRoll =
        (atan2(-accel.x, sqrt(accel.y * accel.y + accel.z * accel.z)) *
            180 /
            pi)
            .toDouble();

    double magX = magnet.x * cos(currentPitch * pi / 180) +
        magnet.y * sin(currentRoll * pi / 180) * sin(currentPitch * pi / 180) +
        magnet.z * cos(currentRoll * pi / 180) * sin(currentPitch * pi / 180);
    double magY = magnet.y * cos(currentRoll * pi / 180) -
        magnet.z * sin(currentRoll * pi / 180);

    currentYaw = (atan2(-magY, magX) * 180 / pi).toDouble();

    if (currentYaw < 0) {
      currentYaw += 360;
    } else if (currentYaw >= 360) {
      currentYaw -= 360;
    }
  }

  void computeOrientationFromGyro(GyroscopeEvent event) {
    if (lastGyroUpdate == null) {
      lastGyroUpdate = DateTime.now();
      return;
    }

    final now = DateTime.now();
    final deltaTime =
        now.difference(lastGyroUpdate!).inMicroseconds / 1000000.0;
    lastGyroUpdate = now;

    double deltaYaw = event.z * deltaTime;

    double updatedYaw = currentYaw + deltaYaw * (180 / pi);

    currentYaw = currentYaw * gyroSmoothing + updatedYaw * (1 - gyroSmoothing);

    if (currentYaw < 0) {
      currentYaw += 360;
    } else if (currentYaw >= 360) {
      currentYaw -= 360;
    }
  }

  Future<void> fetchCurrentLocation() async {
    bool isServiceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!isServiceEnabled) {
      print('Location services are disabled.');
      return;
    }

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        print('Location permissions are denied.');
        return;
      }
    }

    if (permission == LocationPermission.deniedForever) {
      print('Location permissions are permanently denied.');
      return;
    }

    try {
      Position position = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.high);

      setState(() {
        userPosition = position;
      });
    } catch (e) {
      print('Error fetching location: $e');
    }
  }

  void dispatchEmergencyAlert() async {
    if (alertSent) {
      print('Alert already sent this session. Skipping...');
      return; // Exit if alert has already been sent
    }

    if (contacts.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please add at least one emergency contact.'),
        ),
      );
      return;
    }

    if (userPosition == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Current location is unavailable.'),
        ),
      );
      return;
    }

    String mapLink =
        'https://www.google.com/maps/search/?api=1&query=${userPosition!.latitude},${userPosition!.longitude}';
    String baseAlert = 'Alert! Assistance needed.\nLocation: $mapLink\n'
        'Acceleration: ${currentAcceleration?.toStringAsFixed(2) ?? "N/A"} m/s²\n'
        'Orientation - Pitch: ${currentPitch.toStringAsFixed(1)}°, '
        'Roll: ${currentRoll.toStringAsFixed(1)}°, Yaw: ${currentYaw.toStringAsFixed(1)}°';

    String completeMessage = userCustomMessage.isNotEmpty
        ? '$baseAlert\n\n$userCustomMessage'
        : baseAlert;

    try {
      final bool isIOS = Theme.of(context).platform == TargetPlatform.iOS;

      if (isIOS) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('SMS sending is not supported on iOS devices.'),
          ),
        );
      } else {
        for (String contact in contacts) {
          await smsChannel.invokeMethod('sendSMS', {
            'phoneNumber': contact,
            'message': completeMessage,
          });
        }

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Emergency alert successfully sent to all contacts.'),
          ),
        );

        print('Emergency alert successfully sent.');
      }

      alertSent = true; // Set the flag to prevent further alerts in this session
    } on PlatformException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to send alert: ${e.message}'),
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Unexpected error: $e'),
        ),
      );
    }
  }

  void promptContactInput() async {
    final result = await showDialog<Map<String, dynamic>>(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return ContactManagementDialog(
          existingContacts: contacts,
          initialMessage: userCustomMessage,
        );
      },
    );

    if (result != null) {
      setState(() {
        contacts = List<String>.from(result['contacts']);
        userCustomMessage = result['customMessage'];
      });
      // Save contacts and custom message after dialog
      await saveContactsList(contacts);
      await saveCustomMessage(userCustomMessage);
    }
  }

  @override
  Widget build(BuildContext context) {
    String accelDisplay = isAccelAvailable
        ? (filteredAccelerationMagnitude != null
        ? filteredAccelerationMagnitude!.toStringAsFixed(2)
        : "N/A")
        : "Accelerometer unavailable";

    String orientationPitch = "${currentPitch.toStringAsFixed(1)}°";
    String orientationRoll = "${currentRoll.toStringAsFixed(1)}°";
    String orientationYaw = "${currentYaw.toStringAsFixed(1)}°";

    String locationInfo = userPosition != null
        ? 'Lat: ${userPosition!.latitude.toStringAsFixed(4)}, '
        'Lon: ${userPosition!.longitude.toStringAsFixed(4)}'
        : 'Location not available';

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Text(widget.title),
        actions: [
          IconButton(
            icon: const Icon(Icons.contact_phone),
            onPressed: promptContactInput,
          ),
        ],
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: <Widget>[
              const SizedBox(height: 20),
              Text(
                'Acceleration: $accelDisplay m/s²',
                style: Theme.of(context).textTheme.headlineSmall,
              ),
              const SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  IconButton(
                    icon: const Icon(Icons.pin_drop),
                    onPressed: () async {
                      if (userPosition != null) {
                        final lat = userPosition!.latitude;
                        final lon = userPosition!.longitude;

                        final availableMaps = await MapLauncher.installedMaps;

                        if (availableMaps.isNotEmpty) {
                          await availableMaps.first.showMarker(
                            coords: Coords(lat, lon),
                            title: "Your Location",
                          );
                        } else {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                                content: Text(
                                    'No map applications detected.')),
                          );
                        }
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                              content: Text('Location data not available.')),
                        );
                      }
                    },
                  ),
                  Text(
                    locationInfo,
                    style: Theme.of(context).textTheme.bodyLarge,
                  ),
                ],
              ),
              const SizedBox(height: 40),
              Text(
                'Compass',
                style: Theme.of(context).textTheme.headlineSmall,
              ),
              const SizedBox(height: 10),
              SizedBox(
                width: 200,
                height: 200,
                child: CustomPaint(
                  painter: CompassCustomPainter(yaw: currentYaw),
                ),
              ),
              const SizedBox(height: 40),
              Text(
                'Level Indicator',
                style: Theme.of(context).textTheme.headlineSmall,
              ),
              const SizedBox(height: 10),
              SizedBox(
                width: 200,
                height: 200,
                child: CustomPaint(
                  painter: LevelCustomPainter(
                      pitch: currentPitch, roll: currentRoll),
                ),
              ),
              const SizedBox(height: 40),
              if (userCustomMessage.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0),


                  child: Text(
                    'Custom Message:\n$userCustomMessage',
                    style: Theme.of(context).textTheme.bodyMedium,
                    textAlign: TextAlign.center,
                  ),
                ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: dispatchEmergencyAlert,
        backgroundColor: Colors.redAccent,
        child: const Text(
          'SOS',
          style: TextStyle(fontSize: 18, color: Colors.white),
        ),
      ),
    );
  }
}

class ContactManagementDialog extends StatefulWidget {
  final List<String> existingContacts;
  final String initialMessage;

  const ContactManagementDialog({
    super.key,
    required this.existingContacts,
    required this.initialMessage,
  });

  @override
  _ContactManagementDialogState createState() =>
      _ContactManagementDialogState();
}

class _ContactManagementDialogState extends State<ContactManagementDialog> {
  late List<String> tempContacts;
  late String tempCustomMessage;
  final TextEditingController newContactController = TextEditingController();
  final TextEditingController customMessageController = TextEditingController();

  @override
  void initState() {
    super.initState();
    tempContacts = List.from(widget.existingContacts);
    tempCustomMessage = widget.initialMessage;
    customMessageController.text = tempCustomMessage;
  }

  @override
  void dispose() {
    newContactController.dispose();
    customMessageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      insetPadding: const EdgeInsets.all(20),
      child: SizedBox(
        width: double.infinity,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'Emergency Contacts',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 20),
              TextField(
                controller: newContactController,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(
                  labelText: 'New Phone Number',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 10),
              ElevatedButton(
                onPressed: () async {
                  String contact = newContactController.text.trim();
                  if (contact.isNotEmpty && _validatePhoneNumber(contact)) {
                    setState(() {
                      tempContacts.add(contact);
                    });
                    newContactController.clear();
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content:
                        Text('Please enter a valid phone number.'),
                      ),
                    );
                  }
                },
                child: const Text('Add Contact'),
              ),
              const SizedBox(height: 20),
              const Divider(),
              const SizedBox(height: 10),
              const Text(
                'Current Contacts',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 10),
              tempContacts.isEmpty
                  ? const Text('No emergency contacts added.')
                  : ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: tempContacts.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    leading: const Icon(Icons.phone),
                    title: Text(tempContacts[index]),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete, color: Colors.red),
                      onPressed: () {
                        setState(() {
                          tempContacts.removeAt(index);
                        });
                      },
                    ),
                  );
                },
              ),
              const SizedBox(height: 20),
              const Divider(),
              const SizedBox(height: 10),
              const Text(
                'Custom Alert Message',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: customMessageController,
                keyboardType: TextInputType.multiline,
                maxLines: 3,
                decoration: const InputDecoration(
                  labelText: 'Optional custom message',
                  border: OutlineInputBorder(),
                ),
                onChanged: (value) {
                  setState(() {
                    tempCustomMessage = value;
                  });
                },
              ),
              const SizedBox(height: 10),
              ElevatedButton(
                onPressed: () {
                  // Optionally, you can provide immediate feedback
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Custom message updated.'),
                    ),
                  );
                },
                child: const Text('Update Message'),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  Navigator.of(context).pop({
                    'contacts': tempContacts,
                    'customMessage': tempCustomMessage,
                  });
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.grey,
                ),
                child: const Text('Done'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  bool _validatePhoneNumber(String phone) {
    // Simple regex for phone number validation
    final RegExp phoneRegExp = RegExp(r'^\+?\d{7,15}$');
    return phoneRegExp.hasMatch(phone);
  }
}

class CompassCustomPainter extends CustomPainter {
  final double yaw;

  CompassCustomPainter({required this.yaw});

  @override
  void paint(Canvas canvas, Size size) {
    final center = size.center(Offset.zero);
    final radius = min(size.width, size.height) / 2;

    final Paint fillPaint = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.fill;
    final Paint outlinePaint = Paint()
      ..color = Colors.black
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke;
    canvas.drawCircle(center, radius, fillPaint);
    canvas.drawCircle(center, radius, outlinePaint);

    canvas.save();
    canvas.translate(center.dx, center.dy);
    canvas.rotate((yaw + 90) * pi / 180);

    final TextPainter textPainter = TextPainter(
      textAlign: TextAlign.center,
      textDirection: TextDirection.ltr,
    );

    const double labelRadius = 0.85;
    final directions = ['N', 'E', 'S', 'W'];
    for (int i = 0; i < directions.length; i++) {
      final double angle = (pi / 2) * i;
      final Offset labelOffset = Offset(
        radius * labelRadius * cos(angle - pi / 2),
        radius * labelRadius * sin(angle - pi / 2),
      );

      textPainter.text = TextSpan(
        text: directions[i],
        style: const TextStyle(
          color: Colors.black,
          fontSize: 16,
          fontWeight: FontWeight.bold,
        ),
      );
      textPainter.layout();
      final textSize = textPainter.size;
      textPainter.paint(canvas,
          labelOffset - Offset(textSize.width / 2, textSize.height / 2));
    }

    canvas.restore();

    final Paint needlePaint = Paint()
      ..color = Colors.red
      ..strokeWidth = 3
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    final Offset needleEnd = Offset(
      center.dx,
      center.dy - radius * 0.8,
    );

    canvas.drawLine(center, needleEnd, needlePaint);

    final Paint centerDotPaint = Paint()
      ..color = Colors.black
      ..style = PaintingStyle.fill;
    canvas.drawCircle(center, 5, centerDotPaint);
  }

  @override
  bool shouldRepaint(covariant CompassCustomPainter oldDelegate) {
    return oldDelegate.yaw != yaw;
  }
}

class LevelCustomPainter extends CustomPainter {
  final double pitch;
  final double roll;

  LevelCustomPainter({required this.pitch, required this.roll});

  @override
  void paint(Canvas canvas, Size size) {
    final center = size.center(Offset.zero);
    final radius = min(size.width, size.height) / 2;

    final Paint borderPaint = Paint()
      ..color = Colors.black
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke;

    final Paint backgroundPaint = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.fill;

    canvas.drawCircle(center, radius, backgroundPaint);
    canvas.drawCircle(center, radius, borderPaint);

    final Paint axisPaint = Paint()
      ..color = Colors.grey
      ..strokeWidth = 1;

    canvas.drawLine(
      Offset(center.dx - radius, center.dy),
      Offset(center.dx + radius, center.dy),
      axisPaint,
    );

    canvas.drawLine(
      Offset(center.dx, center.dy - radius),
      Offset(center.dx, center.dy + radius),
      axisPaint,
    );

    double maxMovement = radius - 20;

    double clampedPitch = pitch.clamp(-90.0, 90.0);
    double clampedRoll = roll.clamp(-90.0, 90.0);

    double yMovement = (clampedPitch / 90.0) * maxMovement;
    double xMovement = (clampedRoll / 90.0) * maxMovement;

    final Paint indicatorPaint = Paint()
      ..color = Colors.red
      ..style = PaintingStyle.fill;

    canvas.drawCircle(
        Offset(center.dx + xMovement, center.dy + yMovement), 10,
        indicatorPaint);

    final Paint centralDotPaint = Paint()
      ..color = Colors.black
      ..style = PaintingStyle.fill;

    canvas.drawCircle(center, 5, centralDotPaint);
  }

  @override
  bool shouldRepaint(covariant LevelCustomPainter oldDelegate) {
    return oldDelegate.pitch != pitch || oldDelegate.roll != roll;
  }
}
